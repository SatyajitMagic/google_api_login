Rails.application.routes.draw do
  # Define your application routes per the DSL in https://guides.rubyonrails.org/routing.html

  # Defines the root path route ("/")
  # root "articles#index"
 
  root "home#login"
  get '/auth/:provider/callback' => 'sessions#omniauth'
  #get '/auth/login_success/:id' => 'sessions#login_success', defaults: { format: :json }
  get '/session/:id', to: 'sessions#show'
  post '/auth/login', to: 'demos#get_response_frm_client_side', defaults: { format: :json }

  # namespace :api do
  #   namespace :v1 do
  #     #resources :session do
  #       post '/auth/login', to: 'session#get_response_frm_client_side'
  #     #end
  #   end
  # end 
end
