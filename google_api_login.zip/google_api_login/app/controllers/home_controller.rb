class HomeController < ApplicationController
    def login

    end
end
