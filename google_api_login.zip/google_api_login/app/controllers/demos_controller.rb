class DemosController < ApplicationController
    def get_response_frm_client_side
        @user=User.find(1)
        puts "---------get_response_frm_client_side-----------: #{@user.to_json}"
        puts "---------params-----------: #{params}"
        puts "---------params-----------: #{request.headers['Authorization']}"
        render json:@user
    end
end
