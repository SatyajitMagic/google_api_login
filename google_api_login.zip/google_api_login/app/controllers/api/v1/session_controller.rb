class Api::V1::SessionController < ApplicationController
    # def login_success
    #     # @user = User.from_omniauth(auth)
    #     # if @user.save
    #     #     render json: @user, status:ok
    #     # else
    #     #     render json: { }, status:unauthorized
    #     # end
    #     @user=User.find(params[:id])
    #     puts json:{email: @user.email, token: @user.password}
    #     #render json:{email: @user.email, token: @user.password},status:200
    #     return {"message":"User successfully updated."}
    # end
    def show
        @user=User.all
        #puts "--------------------: #{request.env.to_json}"
        render json:@user
    end

    def get_response_frm_client_side
        @user=User.all
        puts "---------get_response_frm_client_side-----------: #{@user.to_json}"
        puts "---------params-----------: #{params}"
        render json:@user
    end
    private

    def auth
        request.env["omniauth.auth"]
    end
end
