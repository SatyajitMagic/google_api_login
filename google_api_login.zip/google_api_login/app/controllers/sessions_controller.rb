class SessionsController < ApplicationController
    skip_before_action :verify_authenticity_token, only: [:omniauth]
    def omniauth
        puts "---------omniauth-----------: #{auth.to_json}"
        
        #Rails.configuration.token="fffffffffffffff"
        @user = User.from_omniauth(auth)
        if @user.save
            #render json: {email: @user.email, token: @user.password}
            # redirect_to "http://localhost:3000"
            render json:@user
        else
            render json: { }, status:unauthorized
        end
    end
    def generate_url(url, params = {})
        uri = URI(url)
        uri.query = params.to_query
        uri.to_s
    end
    def show        
        @user=User.find(1)
        render json:@user
    end

    def get_response_frm_client_side
        #@user=User.find(1)
        puts "---------get_response_frm_client_side-----------: #{@user.to_json}"
        puts "---------params-----------: #{params}"
        #render json:@user
    end
    private

    def auth
        request.env["omniauth.auth"]
    end
end
